#!/bin/bash

env
read x
echo "Hullabulla"

