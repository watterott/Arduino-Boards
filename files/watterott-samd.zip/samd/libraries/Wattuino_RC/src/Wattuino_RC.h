//empty file, workaround for libraries containing only examples
